package org.example.completeapp.entities;


public class PhysicalBook {

}
