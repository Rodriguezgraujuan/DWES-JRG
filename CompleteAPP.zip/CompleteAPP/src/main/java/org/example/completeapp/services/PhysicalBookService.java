package org.example.completeapp.services;


import org.example.completeapp.entities.PhysicalBook;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PhysicalBookService {

    //TODO: Ejercicio 2: implementar el método
    public List<PhysicalBook> findAll() {
        return new ArrayList<>();
    }

    //TODO: Ejercicio 2: implementar el método
    public PhysicalBook findById(Long id) {
        return null;
    }

    //TODO: Ejercicio 2: implementar el método
    public PhysicalBook save(PhysicalBook book) {
        return null;
    }

}
